public class VendingMachineRequest {
    public Product product;
    public CoinBundle enteredCoins;

    public VendingMachineRequest(int selectedProduct, int... enteredCoins){
        
        this.product = Product.EMPTY;
        this.enteredCoins = new CoinBundle(enteredCoins);
    }
}