import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        try (Scanner scanner = new Scanner(System.in)) {
            VendingMachineInterface machineInterface = new TextVendingMachineInterface();

            machineInterface.displayProducts();

            String selectedProduct = scanner.nextLine();
            machineInterface.selectProduct(Integer.parseInt(selectedProduct));

            machineInterface.displayEnterCoinsMessage();

            String userEnteredCoins = scanner.nextLine();
            int[] enteredCoins = Coin.parseCoins(userEnteredCoins);
            machineInterface.enterCoins(enteredCoins);

            machineInterface.displayChangeMessage();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

    }
}